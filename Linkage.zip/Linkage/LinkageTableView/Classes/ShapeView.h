//
//  ShapeView.h
//  LinkageTableView
//
//  Created by Mac on 2018/1/12.
//  Copyright © 2018年 z. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShapeView : UIView

@property (nonatomic, strong) UIColor *bgColor;

@end
